# main_gui.py
import sys
import os
import time # Para el indicador de "Procesando..."
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
                             QTextEdit, QPushButton, QLabel, QFileDialog,
                             QMessageBox, QSplitter, QGroupBox,
                             QSizePolicy, QCheckBox, QStatusBar, QMainWindow,
                             QDialog, QPlainTextEdit, QTreeView) # Añadido QTreeView
from PyQt5.QtGui import QFont, QColor, QTextCharFormat, QSyntaxHighlighter, QStandardItemModel
from PyQt5.QtCore import Qt, QSize, QRegExp, QSettings # QSettings para recordar directorio

# Importar desde analyzer_core
try:
    from analyzer_core import analyze_and_transform, NaturalToJsonLexer # Necesitamos Lexer para el Highlighter
except ImportError:
    if '..' not in sys.path:
        sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    try:
        from analyzer_core import analyze_and_transform, NaturalToJsonLexer
    except ImportError as e_imp:
        QMessageBox.critical(None, "Error de Importación Crítico", 
                             f"No se pudo importar 'analyzer_core'. Asegúrate de que está en la ruta correcta.\nDetalle: {e_imp}")
        sys.exit(1)

# --- Constantes ---
APP_NAME = "Natural a JSON - Analizador PRO"
ORG_NAME = "MiProyecto" # Para QSettings
DEFAULT_EXAMPLES_DIR = "ejemplos_entrada"
DEFAULT_OUTPUT_DIR = "salidas_json"

# --- Resaltador de Sintaxis Básico (Simplificado) ---
class NaturalSyntaxHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlighting_rules = []

        keyword_format = QTextCharFormat(); keyword_format.setForeground(QColor("#000080")); keyword_format.setFontWeight(QFont.Bold)
        keywords = ["CREAR", "OBJETO", "LISTA", "CON", "ELEMENTOS", "VERDADERO", "FALSO"] # Insensible en lexer, aquí sensible
        # Añadir variantes en minúsculas y capitalizadas para el resaltado visual
        keywords_variants = []; [keywords_variants.extend([kw, kw.lower(), kw.capitalize()]) for kw in keywords]

        for word in keywords_variants:
            pattern = QRegExp(f"\\b{word}\\b")
            self.highlighting_rules.append((pattern, keyword_format))

        identifier_format = QTextCharFormat(); identifier_format.setForeground(QColor("#006400"))
        # No podemos usar la regla léxica completa aquí fácilmente, simplificamos
        self.highlighting_rules.append((QRegExp("\\b[a-zA-Z_ñÑáéíóúÁÉÍÓÚüÜ][a-zA-Z0-9_ñÑáéíóúÁÉÍÓÚüÜ]*\\b"), identifier_format))
        
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#8B0000")) # Rojo oscuro
        self.highlighting_rules.append((QRegExp("\\b-?[0-9]+(\\.[0-9]+)?\\b"), number_format))

        string_format = QTextCharFormat(); string_format.setForeground(QColor("#A52A2A"))
        self.highlighting_rules.append((QRegExp("\".*\""), string_format))

        comment_format = QTextCharFormat(); comment_format.setForeground(QColor("#008080")); comment_format.setFontItalic(True)
        self.highlighting_rules.append((QRegExp("//[^\n]*"), comment_format))

    def highlightBlock(self, text):
        for pattern, format_rule in self.highlighting_rules:
            expression = QRegExp(pattern); index = expression.indexIn(text)
            while index >= 0:
                length = expression.matchedLength(); self.setFormat(index, length, format_rule); index = expression.indexIn(text, index + length)
        self.setCurrentBlockState(0)

# --- Ventana Principal ---
class NaturalToJsonApp(QMainWindow): # Cambiado a QMainWindow
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Natural a JSON - Analizador PRO v2")
        self.setGeometry(50, 50, 1440, 880)
        self.settings = QSettings("MiProyecto", "NaturalToJsonApp") 
        self.initUI()
        self.current_input_filepath = None
        self.last_used_dir = self.settings.value("lastUsedDirectory", os.path.expanduser("~"))
        self.readSettings() # Cargar geometría al final de __init__

    def initUI(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # --- Menú (si se usa QMainWindow) ---
        # self.createActions()
        # self.createMenus() # Descomentar si se implementa un menú completo

        # --- Grupo de Entrada ---
        input_groupbox = QGroupBox("Entrada de Comandos")
        input_groupbox.setFont(QFont("Arial", 11, QFont.Bold))
        input_layout = QVBoxLayout()
        self.input_text_edit = QTextEdit()
        self.input_text_edit.setFont(QFont("Consolas", 11))
        self.input_text_edit.setPlaceholderText("Ej: CREAR OBJETO miLibro CON titulo:\"El Quijote\"...")
        self.highlighter = NaturalSyntaxHighlighter(self.input_text_edit.document()) # Resaltador
        input_layout.addWidget(self.input_text_edit)
        action_buttons_layout = QHBoxLayout()
        # ... (botones como antes: Cargar, Guardar Entrada, Ayuda, Limpiar, Analizar) ...
        self.load_button = QPushButton(" Cargar Archivo..."); self.load_button.clicked.connect(self.loadFile)
        action_buttons_layout.addWidget(self.load_button)
        self.save_input_button = QPushButton(" Guardar Entrada..."); self.save_input_button.clicked.connect(self.saveInputText)
        action_buttons_layout.addWidget(self.save_input_button)
        action_buttons_layout.addStretch()
        self.help_button = QPushButton(" Ayuda/Ejemplos"); self.help_button.clicked.connect(self.showHelp)
        action_buttons_layout.addWidget(self.help_button)
        self.clear_button = QPushButton(" Limpiar Todo"); self.clear_button.clicked.connect(self.clearAllFields)
        action_buttons_layout.addWidget(self.clear_button)
        self.analyze_button = QPushButton(" Analizar y Convertir")
        self.analyze_button.setStyleSheet("font-weight: bold; padding: 8px; background-color: #4CAF50; color: white;")
        self.analyze_button.clicked.connect(self.runAnalysis)
        action_buttons_layout.addWidget(self.analyze_button)
        
        input_layout.addLayout(action_buttons_layout)
        input_groupbox.setLayout(input_layout)

        # --- Grupo de Salida con Splitter y Checkboxes para visibilidad ---
        output_groupbox = QGroupBox("Resultados del Análisis")
        output_groupbox.setFont(QFont("Arial", 11, QFont.Bold))
        output_main_layout = QVBoxLayout()

        # Checkboxes para visibilidad
        visibility_layout = QHBoxLayout()
        self.cb_show_tokens = QCheckBox("Mostrar Tokens"); self.cb_show_tokens.setChecked(True); self.cb_show_tokens.toggled.connect(self.toggleOutputVisibility)
        visibility_layout.addWidget(self.cb_show_tokens)
        self.cb_show_tree = QCheckBox("Mostrar Árbol de Parseo"); self.cb_show_tree.setChecked(True); self.cb_show_tree.toggled.connect(self.toggleOutputVisibility)
        visibility_layout.addWidget(self.cb_show_tree)
        visibility_layout.addStretch()
        output_main_layout.addLayout(visibility_layout)

        self.output_splitter = QSplitter(Qt.Horizontal)

        # Columna Izquierda (Tokens y Árbol)
        self.left_output_widget = QWidget() # Contenedor para visibilidad
        left_column_layout = QVBoxLayout(self.left_output_widget)
        
        self.tokens_output_label = QLabel("Tokens Reconocidos:")
        self.tokens_output_text = QPlainTextEdit(); self.tokens_output_text.setReadOnly(True); 
        self.tokens_output_text.setFont(QFont("Consolas", 9)); self.tokens_output_text.setLineWrapMode(QPlainTextEdit.NoWrap)
        left_column_layout.addWidget(self.tokens_output_label)
        left_column_layout.addWidget(self.tokens_output_text)

        # --- CAMBIO: QTreeView para el Árbol de Parseo ---
        self.parsetree_output_label = QLabel("Árbol de Parseo Interactivo:") # Título cambiado
        self.parsetree_view = QTreeView() # Nuevo QTreeView
        self.parsetree_view.setFont(QFont("Arial", 9))
        self.parsetree_view.setHeaderHidden(True) # No necesitamos encabezados de columna
        self.parsetree_view.setAlternatingRowColors(True)
        # self.parsetree_view.setEditTriggers(QAbstractItemView.NoEditTriggers) # Ya se hace en el item
        left_column_layout.addWidget(self.parsetree_output_label)
        left_column_layout.addWidget(self.parsetree_view) # Añadir QTreeView en lugar de QPlainTextEdit
        
        self.output_splitter.addWidget(self.left_output_widget)

        # Columna Derecha (JSON y Errores)
        right_column_widget = QWidget()
        right_column_layout = QVBoxLayout(right_column_widget)
        self.json_output_label = QLabel("JSON Generado:")
        self.json_output_text = QPlainTextEdit(); self.json_output_text.setReadOnly(True); 
        self.json_output_text.setFont(QFont("Consolas", 10)); self.json_output_text.setLineWrapMode(QPlainTextEdit.NoWrap)
        right_column_layout.addWidget(self.json_output_label)
        right_column_layout.addWidget(self.json_output_text)

        self.errors_output_label = QLabel("Resumen de Errores:")
        self.errors_output_text = QPlainTextEdit()
        self.errors_output_text.setReadOnly(True)
        self.errors_output_text.setFont(QFont("Consolas", 9))
        self.errors_output_text.setStyleSheet("color: #B71C1C; background-color: #FFCDD2;")
        right_column_layout.addWidget(self.errors_output_label)
        right_column_layout.addWidget(self.errors_output_text)
        
        self.output_splitter.addWidget(right_column_widget)
        self.output_splitter.setSizes([self.width() // 2, self.width() // 2]) # Distribuir equitativamente

        output_main_layout.addWidget(self.output_splitter)
        
        # Botón y Label para estadísticas
        stats_and_save_layout = QHBoxLayout()
        self.stats_label = QLabel("Estadísticas: N/A")
        stats_and_save_layout.addWidget(self.stats_label, 1)
        self.save_json_button = QPushButton(" Guardar JSON...");
        self.save_json_button.clicked.connect(self.saveJsonOutput); self.save_json_button.setEnabled(False)
        stats_and_save_layout.addWidget(self.save_json_button)
        output_main_layout.addLayout(stats_and_save_layout)

        output_groupbox.setLayout(output_main_layout)

        # Barra de estado
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Listo.")

        main_layout.addWidget(input_groupbox, 2) # Ajustar stretch factors
        main_layout.addWidget(output_groupbox, 5)
        
        self.toggleOutputVisibility() # Aplicar visibilidad inicial

    def clearAllFields(self):
        self.input_text_edit.clear()
        self.tokens_output_text.clear()
        # Limpiar QTreeView
        empty_model = QStandardItemModel() # Crear modelo vacío
        self.parsetree_view.setModel(empty_model) # Asignar modelo vacío
        # self.parsetree_output_text.clear() # Ya no existe este widget
        self.json_output_text.clear()
        self.errors_output_text.clear()
        self.save_json_button.setEnabled(False)
        self.current_input_filepath = None
        self.stats_label.setText("Estadísticas: N/A")
        self.statusBar.showMessage("Campos limpiados. Listo.")
        self.input_text_edit.setFocus()


    def toggleOutputVisibility(self):
        self.tokens_output_label.setVisible(self.cb_show_tokens.isChecked())
        self.tokens_output_text.setVisible(self.cb_show_tokens.isChecked())
        # Visibilidad para QTreeView
        self.parsetree_output_label.setVisible(self.cb_show_tree.isChecked())
        self.parsetree_view.setVisible(self.cb_show_tree.isChecked()) # Controlar QTreeView
        # Ajustar visibilidad del contenedor si ambos están ocultos
        self.left_output_widget.setVisible(self.cb_show_tokens.isChecked() or self.cb_show_tree.isChecked())


    def showHelp(self):
        # ... (Función showHelp sin cambios, ya es buena) ...
        help_text = """
        <h2>Ayuda - Sintaxis "Natural a JSON"</h2>
        <p>Este analizador convierte comandos simples en español a formato JSON.</p>
        
        <h3>Comandos Soportados:</h3>
        <ol>
            <li><b>Crear Objeto:</b>
                <pre>CREAR OBJETO <nombreDelObjeto> CON <clave1>:<valor1>, <clave2>:<valor2>, ...</pre>
                <p>Ejemplo:</p>
                <pre>CREAR OBJETO libro CON titulo:"Cien Años", autor:"Gabo", publicado:1967, bestseller:VERDADERO</pre>
            </li>
            <li><b>Crear Lista:</b>
                <pre>CREAR LISTA <nombreDeLaLista> CON ELEMENTOS <valor1>, <valor2>, ...</pre>
                <p>Ejemplo:</p>
                <pre>CREAR LISTA compras CON ELEMENTOS "Leche", "Huevos", 12, 3.50, FALSO</pre>
            </li>
        </ol>

        <h3>Tipos de Valores Soportados:</h3>
        <ul>
            <li><b>Texto (String):</b> Entre comillas dobles. Ej: <code>"Hola Mundo"</code></li>
            <li><b>Número Entero:</b> Ej: <code>123</code>, <code>-45</code></li>
            <li><b>Número Decimal:</b> Ej: <code>3.14</code>, <code>-0.05</code></li>
            <li><b>Booleano:</b> <code>VERDADERO</code> o <code>FALSO</code> (insensible a mayúsculas)</li>
        </ul>

        <h3>Identificadores (Nombres y Claves):</h3>
        <p>Deben empezar con una letra (a-z, A-Z, incluyendo ñ, acentos) o guion bajo (_), 
        seguido de letras, números o guion bajo.</p>
        <p>Ej: <code>mi_objeto</code>, <code>año</code>, <code>descripción_producto</code></p>

        <h3>Comentarios:</h3>
        <p>Las líneas que empiezan con <code>//</code> son ignoradas.</p>
        <pre>// Esto es un comentario</pre>
        """
        QMessageBox.information(self, "Ayuda y Ejemplos de Sintaxis", help_text)


    def loadFile(self):
        options = QFileDialog.Options()
        fileName, _ = QFileDialog.getOpenFileName(self, "Cargar Archivo Natural a JSON", self.last_used_dir,
                                                  "Archivos de Texto (*.txt);;Todos los Archivos (*)", options=options)
        if fileName:
            try:
                with open(fileName, 'r', encoding='utf-8') as f:
                    self.input_text_edit.setPlainText(f.read())
                self.current_input_filepath = fileName
                self.last_used_dir = os.path.dirname(fileName) # Recordar directorio
                self.settings.setValue("lastUsedDirectory", self.last_used_dir)
                self.statusBar.showMessage(f"Archivo '{os.path.basename(fileName)}' cargado.", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error al Cargar", f"No se pudo cargar el archivo:\n{e}")
                self.statusBar.showMessage(f"Error al cargar archivo.", 5000)

    def saveInputText(self):
        content = self.input_text_edit.toPlainText()
        if not content.strip():
            QMessageBox.warning(self, "Guardar Entrada", "No hay contenido para guardar.")
            return

        options = QFileDialog.Options()
        suggested_name = os.path.basename(self.current_input_filepath) if self.current_input_filepath else "entrada.txt"
        fileName, _ = QFileDialog.getSaveFileName(self, "Guardar Entrada como Archivo de Texto", 
                                                  os.path.join(self.last_used_dir, suggested_name),
                                                  "Archivos de Texto (*.txt);;Todos los Archivos (*)", options=options)
        if fileName:
            if not fileName.endswith(".txt"): fileName += ".txt"
            try:
                with open(fileName, 'w', encoding='utf-8') as f:
                    f.write(content)
                self.current_input_filepath = fileName
                self.last_used_dir = os.path.dirname(fileName)
                self.settings.setValue("lastUsedDirectory", self.last_used_dir)
                self.statusBar.showMessage(f"Entrada guardada en '{os.path.basename(fileName)}'.", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error al Guardar", f"No se pudo guardar la entrada:\n{e}")
                self.statusBar.showMessage("Error al guardar entrada.", 5000)

    def runAnalysis(self):
        input_content = self.input_text_edit.toPlainText()
        if not input_content.strip():
            QMessageBox.warning(self, "Entrada Vacía", "Por favor, ingresa comandos o carga un archivo.")
            self.statusBar.showMessage("Análisis cancelado: entrada vacía.", 5000)
            return

        self.tokens_output_text.clear()
        # self.parsetree_output_text.clear() # Ya no existe
        self.parsetree_view.setModel(QStandardItemModel()) # Limpiar vista de árbol
        self.json_output_text.clear()
        self.errors_output_text.clear()
        self.stats_label.setText("Estadísticas: N/A")
        self.save_json_button.setEnabled(False)
        self.statusBar.showMessage("Analizando... Por favor espera.", 3000) # Mensaje temporal
        QApplication.processEvents() 

        source_name = os.path.basename(self.current_input_filepath) if self.current_input_filepath else "entrada_directa_gui"
        
        try:
            # analyze_and_transform ahora devuelve parsetree_qt_model en lugar de tree_s
            json_s, tokens_s, parsetree_qt_model, errors_s, stats = analyze_and_transform(source_name, input_content)

            self.tokens_output_text.setPlainText(tokens_s)
            
            if errors_s:
                self.errors_output_text.setPlainText(errors_s)
            
            if json_s and parsetree_qt_model: # Si no hubo errores y se generó el modelo del árbol
                self.parsetree_view.setModel(parsetree_qt_model) # Asignar el modelo al QTreeView
                self.parsetree_view.expandAll() # Expandir todos los nodos por defecto
                self.json_output_text.setPlainText(json_s)
                self.save_json_button.setEnabled(True)
                self.statusBar.showMessage(f"Análisis completado para '{source_name}'. JSON generado.", 10000)
            elif not json_s and parsetree_qt_model is None and errors_s: # Errores impidieron generar árbol/json
                self.statusBar.showMessage(f"Análisis para '{source_name}' completado con errores.", 10000)
            else: # Caso inesperado
                self.statusBar.showMessage(f"Análisis para '{source_name}' finalizado. Resultado inesperado.", 10000)
            
            # Mostrar estadísticas
            stats_text = (f"Tiempo: {stats['tiempo_analisis_seg']}s | "
                          f"Comandos: {stats['comandos_procesados']} | "
                          f"Tokens (Parser): {stats['tokens_al_parser']} | "
                          f"Err.Léxicos: {stats['errores_lexicos']} | "
                          f"Err.Sintácticos: {stats['errores_sintacticos']}")
            self.stats_label.setText(stats_text)

        except Exception as e:
            critical_error_msg = f"Error Crítico en Motor de Análisis:\n{type(e).__name__}: {e}\n{e.__traceback__}"
            QMessageBox.critical(self, "Error Crítico en Análisis", critical_error_msg)
            self.errors_output_text.setPlainText(critical_error_msg)
            self.statusBar.showMessage("Error crítico durante el análisis.", 5000)

    def saveJsonOutput(self):
        json_content = self.json_output_text.toPlainText()
        if not json_content.strip():
            QMessageBox.warning(self, "Guardar JSON", "No hay JSON generado para guardar.")
            return
        options = QFileDialog.Options(); default_filename = "salida.json"
        if self.current_input_filepath: base, _ = os.path.splitext(os.path.basename(self.current_input_filepath)); default_filename = base + "_output.json"
        output_dir_to_try = os.path.join(self.last_used_dir, DEFAULT_OUTPUT_DIR)
        if not os.path.exists(output_dir_to_try):
            try: os.makedirs(output_dir_to_try)
            except OSError: output_dir_to_try = self.last_used_dir # Fallback al último directorio usado
        
        fileName, _ = QFileDialog.getSaveFileName(self, "Guardar JSON Generado", os.path.join(output_dir_to_try, default_filename),
                                                   "Archivos JSON (*.json);;Todos (*)", options=options)
        if fileName:
            if not fileName.endswith(".json"): fileName += ".json"
            try:
                with open(fileName, 'w', encoding='utf-8') as f: f.write(json_content)
                self.statusBar.showMessage(f"JSON guardado en '{os.path.basename(fileName)}'.", 5000)
                self.last_used_dir = os.path.dirname(fileName); self.settings.setValue("lastUsedDirectory", self.last_used_dir)
            except Exception as e: QMessageBox.critical(self, "Error al Guardar JSON", f"No se pudo guardar:\n{e}"); 
            self.statusBar.showMessage("Error al guardar JSON.", 5000)

    def closeEvent(self, event): self.settings.setValue("lastUsedDirectory", self.last_used_dir); self.settings.setValue("windowGeometry", self.saveGeometry()); super().closeEvent(event)
    def readSettings(self): geometry = self.settings.value("windowGeometry"); self.last_used_dir = self.settings.value("lastUsedDirectory", os.path.expanduser("~"));  (self.restoreGeometry(geometry) if geometry else None)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    # Cargar configuraciones antes de mostrar la ventana
    # Esto se hace mejor si NaturalToJsonApp hereda de QMainWindow y se llama readSettings en __init__
    # Por ahora, lo dejamos así, pero para una app más compleja, se haría en el __init__ de la ventana.
    
    ex = NaturalToJsonApp()
    ex.readSettings() # Cargar geometría y último directorio
    ex.show()
    sys.exit(app.exec_())