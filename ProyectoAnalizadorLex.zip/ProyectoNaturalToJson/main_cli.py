# main_cli.py
import sys
import argparse
import os
from analyzer_core import analyze_and_transform # Importamos la función principal del motor

def list_and_select_test_file(test_files_dir="ejemplos_entrada", file_extension=".txt", processed_files=None):
    # ... (Esta función se mantiene igual que en tu última versión de main.py) ...
    if processed_files is None:
        processed_files = set()

    if not os.path.exists(test_files_dir) or not os.path.isdir(test_files_dir):
        print(f"ADVERTENCIA: Directorio de pruebas '{test_files_dir}' no encontrado.", file=sys.stderr)
        return None, processed_files

    available_files = []
    try:
        all_entries = os.listdir(test_files_dir)
        for entry in all_entries:
            if entry.endswith(file_extension) and os.path.isfile(os.path.join(test_files_dir, entry)):
                available_files.append(entry)
    except OSError as e:
        print(f"Error listando archivos en '{test_files_dir}': {e}", file=sys.stderr)
        return None, processed_files

    if not available_files:
        print(f"No se encontraron archivos '{file_extension}' en '{test_files_dir}'.", file=sys.stderr)
        return None, processed_files

    print("\nArchivos de prueba disponibles en '{}':".format(test_files_dir))
    displayable_files = []
    for i, filename in enumerate(available_files):
        marker = "[✓]" if filename in processed_files else "[ ]"
        print(f"  {marker} {i+1}. {filename}")
        displayable_files.append(filename)
    
    if len(processed_files) == len(available_files) and available_files:
         print("Todos los archivos disponibles han sido procesados en esta sesión.")

    while True:
        try:
            choice = input(f"Selecciona un archivo por número (1-{len(displayable_files)}), 'todos', o 's' para salir: ").strip().lower()
            if choice == 's':
                return "salir", processed_files
            if choice == 'todos':
                return "todos", processed_files
            
            choice_num = int(choice)
            if 1 <= choice_num <= len(displayable_files):
                selected_filename = displayable_files[choice_num - 1]
                # No marcamos como procesado aquí, solo devolvemos la selección
                return os.path.join(test_files_dir, selected_filename), processed_files
            else:
                print("Selección inválida. Intenta de nuevo.")
        except ValueError:
            print("Entrada inválida. Por favor, ingresa un número, 'todos' o 's'.")
        except Exception as e:
            print(f"Ocurrió un error inesperado durante la selección: {e}")
            return None, processed_files


def run_analysis_for_cli(source_name, content):
    """Función helper para ejecutar y mostrar resultados en CLI."""
    print("\n" + "═"*70)
    print(f"║ Iniciando Análisis para: '{source_name}'".center(70-4) + " ║")
    print("═"*70)

    json_s, tokens_s, tree_s, errors_s = analyze_and_transform(source_name, content)

    print(tokens_s)
    if errors_s:
        print(errors_s, file=sys.stderr) # Errores a stderr
    
    if json_s: # Si no hubo errores y se generó JSON
        print(tree_s) # Imprimir árbol solo si no hay errores graves
        print("--- JSON Generado ---")
        print(json_s)
        print("---------------------")
        print("\nProceso completado exitosamente. JSON generado.")

        # Opción para guardar
        save_choice = input("¿Desea guardar este JSON en un archivo? (s/n): ").strip().lower()
        if save_choice == 's':
            default_output_filename = os.path.splitext(os.path.basename(source_name))[0] + "_output.json"
            output_filename = input(f"Ingrese nombre para el archivo JSON (default: {default_output_filename}): ").strip()
            if not output_filename:
                output_filename = default_output_filename
            try:
                with open(output_filename, "w", encoding="utf-8") as outfile:
                    outfile.write(json_s)
                print(f"JSON guardado en '{output_filename}'")
            except Exception as e:
                print(f"Error al guardar el archivo JSON: {e}", file=sys.stderr)

    elif errors_s: # Si hubo errores reportados
        print("\nEl proceso finalizó con errores. Revisar el resumen de errores.", file=sys.stderr)
    else: # Caso inesperado
        print("\nEl análisis no produjo resultado y no reportó errores explícitamente.", file=sys.stderr)


def main_cli():
    default_examples_dir = "ejemplos_entrada"
    if not os.path.exists(default_examples_dir):
        try:
            os.makedirs(default_examples_dir)
            print(f"INFO: Directorio '{default_examples_dir}' creado. Coloca tus archivos .txt de prueba aquí.")
        except OSError as e:
            print(f"ADVERTENCIA: No se pudo crear el directorio '{default_examples_dir}': {e}", file=sys.stderr)

    arg_parser = argparse.ArgumentParser(
        description='Analizador (CLI) para lenguaje "Natural a JSON".',
        formatter_class=argparse.RawTextHelpFormatter
    )
    arg_parser.add_argument(
        'input_file', nargs='?', type=str, default=None,
        help='(Opcional) Archivo de entrada a procesar directamente.'
    )
    args = arg_parser.parse_args()

    processed_in_session = set()

    if args.input_file:
        source_name = args.input_file
        try:
            with open(args.input_file, 'r', encoding='utf-8') as f:
                content = f.read()
            run_analysis_for_cli(source_name, content)
        except FileNotFoundError:
            print(f"Error Crítico: Archivo '{args.input_file}' no encontrado.", file=sys.stderr); sys.exit(1)
        except Exception as e:
            print(f"Error Crítico al leer archivo '{args.input_file}': {e}", file=sys.stderr); sys.exit(1)
    else:
        while True:
            print("\n" + "="*70)
            print("MODO INTERACTIVO CLI - SELECCIÓN DE ARCHIVO".center(70))
            print("="*70)
            
            selection_result, temp_processed = list_and_select_test_file(default_examples_dir, processed_files=processed_in_session)
            # list_and_select_test_file ya no modifica processed_in_session directamente

            if selection_result == "salir" or selection_result is None:
                print("Saliendo del modo interactivo.")
                break
            
            files_to_process_this_round = []
            if selection_result == "todos":
                print("\nProcesando todos los archivos no procesados en '{}'...".format(default_examples_dir))
                all_files_in_dir = [os.path.join(default_examples_dir, f) 
                                    for f in os.listdir(default_examples_dir) 
                                    if f.endswith(".txt") and os.path.isfile(os.path.join(default_examples_dir, f))]
                
                for file_path in all_files_in_dir:
                    if os.path.basename(file_path) not in processed_in_session:
                        files_to_process_this_round.append(file_path)
                
                if not files_to_process_this_round and all_files_in_dir:
                     print("Todos los archivos ya habían sido procesados en esta sesión.")
                elif not all_files_in_dir:
                     print(f"No se encontraron archivos .txt en '{default_examples_dir}'.")
            else:
                files_to_process_this_round.append(selection_result)

            for file_path_to_process in files_to_process_this_round:
                filename_only = os.path.basename(file_path_to_process)
                try:
                    with open(file_path_to_process, 'r', encoding='utf-8') as f:
                        content = f.read()
                    run_analysis_for_cli(filename_only, content) # Usar filename_only para source_name
                    processed_in_session.add(filename_only) # Marcar como procesado
                except Exception as e:
                    print(f"Error procesando '{filename_only}': {e}", file=sys.stderr)
            
            if selection_result != "salir":
                cont = input("\n¿Desea procesar otro archivo o ver la lista? (s/n): ").strip().lower()
                if cont != 's':
                    print("Saliendo del modo interactivo.")
                    break
            else:
                break

if __name__ == '__main__':
    main_cli()