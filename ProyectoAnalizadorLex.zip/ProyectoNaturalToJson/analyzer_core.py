# analyzer_core.py
import sys
import json
import time
from antlr4 import *
from antlr4.InputStream import InputStream
from antlr4.CommonTokenStream import CommonTokenStream
from antlr4.tree.Trees import Trees # Lo seguiremos usando para la representación LISP textual
from antlr4.error.ErrorListener import ErrorListener

# Importaciones de PyQt5 para el modelo del árbol
from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5.QtCore import Qt

if './generated' not in sys.path:
    sys.path.append('./generated')

from NaturalToJsonLexer import NaturalToJsonLexer
from NaturalToJsonParser import NaturalToJsonParser
from NaturalToJsonListener import NaturalToJsonListener

# --- CustomErrorListener (sin cambios respecto a la última versión con traducciones) ---
class CustomErrorListener(ErrorListener):
    # ... (código completo del CustomErrorListener como lo teníamos) ...
    def __init__(self, source_name="<input>"):
        super().__init__()
        self.source_name = source_name
        self._lexer_errors = 0
        self._parser_errors = 0
        self.error_messages = []

    @property
    def lexer_errors(self): return self._lexer_errors
    @property
    def parser_errors(self): return self._parser_errors

    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
        error_type = "Desconocido"
        user_column = column + 1 
        detailed_msg = msg
        is_lexer_error = isinstance(recognizer, NaturalToJsonLexer)

        if is_lexer_error:
            self._lexer_errors += 1
            error_type = "Léxico"
            if "token recognition error at: '" in msg:
                try:
                    char_problem = msg.split("token recognition error at: '")[1][:-1]
                    detailed_msg = f"Carácter inesperado o no reconocido: '{char_problem}'."
                except IndexError: detailed_msg = "Error de reconocimiento de token no especificado."
            else: detailed_msg = f"Error léxico general: {msg}"
        else:
            self._parser_errors += 1
            error_type = "Sintáctico"
            offending_text = offendingSymbol.text if offendingSymbol else ""
            if offending_text == '<EOF>': offending_text = "fin de la entrada"
            
            if "mismatched input" in msg and "expecting" in msg:
                try:
                    expected_tokens = msg.split("expecting ")[1]
                    detailed_msg = f"Se encontró '{offending_text}' pero se esperaba {expected_tokens}."
                except: detailed_msg = f"Entrada no coincide: '{offending_text}'. {msg}"
            elif "extraneous input" in msg and "expecting" in msg:
                try:
                    expected_tokens = msg.split("expecting ")[1]
                    detailed_msg = f"Entrada adicional o fuera de lugar: '{offending_text}'. Se esperaba {expected_tokens} antes o después."
                except: detailed_msg = f"Entrada sobrante: '{offending_text}'. {msg}"
            elif "missing" in msg and "at" in msg:
                try:
                    missing_token = msg.split("missing ")[1].split(" at")[0]
                    detailed_msg = f"Falta el símbolo/palabra clave '{missing_token}' cerca de '{offending_text}'."
                except: detailed_msg = f"Elemento faltante. {msg}"
            elif "no viable alternative at input" in msg:
                detailed_msg = f"No se reconoce la estructura del comando cerca de '{offending_text}'. Verifica la sintaxis."
            else: detailed_msg = f"Error de estructura cerca de '{offending_text}'. Detalle: {msg}"
        
        final_error_message = f"Error {error_type} en '{self.source_name}' (Línea {line}:Columna {user_column}): {detailed_msg}"
        self.error_messages.append(final_error_message)

    def get_total_errors(self): return self._lexer_errors + self._parser_errors
    def get_error_summary_string(self):
        if not self.error_messages: return ""
        summary = "╔═════════════════════════════════════╗\n"
        summary += "║     Resumen de Errores Detectados     ║\n"
        summary += "╚═════════════════════════════════════╝\n"
        summary += "\n".join([f"  ⚠️  {emsg}" for emsg in self.error_messages])
        return summary

# --- Listener para Construir JSON (sin cambios) ---
class JsonBuilderListener(NaturalToJsonListener):
    # ... (código completo del JsonBuilderListener como lo teníamos) ...
    def __init__(self):
        self.result_data = {}
        self.current_object_name = None
        self.current_object_props = {}
        self.current_list_name = None
        self.current_list_items = []
        self.current_key = None

    def get_final_json_string(self):
        return json.dumps(self.result_data, indent=2, ensure_ascii=False)

    def enterCrear_objeto_cmd(self, ctx:NaturalToJsonParser.Crear_objeto_cmdContext):
        self.current_object_name = ctx.nombre_obj.text
        self.current_object_props = {}

    def exitCrear_objeto_cmd(self, ctx:NaturalToJsonParser.Crear_objeto_cmdContext):
        if self.current_object_name:
            self.result_data[self.current_object_name] = self.current_object_props
        self.current_object_name = None

    def enterPropiedad(self, ctx:NaturalToJsonParser.PropiedadContext):
        self.current_key = ctx.clave.text

    def exitPropiedad(self, ctx:NaturalToJsonParser.PropiedadContext):
        if self.current_key and hasattr(ctx, 'valor_procesado'):
             self.current_object_props[self.current_key] = ctx.valor_procesado
        self.current_key = None

    def enterCrear_lista_cmd(self, ctx:NaturalToJsonParser.Crear_lista_cmdContext):
        self.current_list_name = ctx.nombre_lista.text
        self.current_list_items = []

    def exitCrear_lista_cmd(self, ctx:NaturalToJsonParser.Crear_lista_cmdContext):
        if self.current_list_name:
            self.result_data[self.current_list_name] = self.current_list_items
        self.current_list_name = None

    def exitValor(self, ctx:NaturalToJsonParser.ValorContext):
        processed_value = None
        if ctx.STRING():
            processed_value = ctx.STRING().getText()[1:-1]
        elif ctx.NUMERO_ENTERO():
            processed_value = int(ctx.NUMERO_ENTERO().getText())
        elif ctx.NUMERO_DECIMAL():
            processed_value = float(ctx.NUMERO_DECIMAL().getText())
        elif ctx.KW_VERDADERO():
            processed_value = True
        elif ctx.KW_FALSO():
            processed_value = False
        
        parent_ctx = ctx.parentCtx
        if isinstance(parent_ctx, NaturalToJsonParser.PropiedadContext):
            parent_ctx.valor_procesado = processed_value
        elif self.current_list_name is not None and isinstance(parent_ctx, NaturalToJsonParser.Items_listaContext):
             self.current_list_items.append(processed_value)
        elif isinstance(parent_ctx, NaturalToJsonParser.Items_listaContext):
            self.current_list_items.append(processed_value)


# --- NUEVO Listener para construir el QStandardItemModel para QTreeView ---
class ParseTreeModelBuilder(NaturalToJsonListener):
    def __init__(self, parser_rule_names):
        super().__init__()
        self.model = QStandardItemModel()
        self.parser_rule_names = parser_rule_names # Nombres de las reglas del parser
        self.item_stack = [] # Pila para mantener el item padre actual

    def get_model(self):
        return self.model

    def enterEveryRule(self, ctx:ParserRuleContext):
        # Obtener el nombre de la regla
        rule_name_index = ctx.getRuleIndex()
        rule_name = self.parser_rule_names[rule_name_index]
        
        item_text = f"{rule_name}"
        current_item = QStandardItem(item_text)
        current_item.setEditable(False) # Los nodos del árbol no son editables

        if not self.item_stack: # Si la pila está vacía, es un nodo raíz
            self.model.appendRow(current_item)
        else: # Añadir como hijo del item en el tope de la pila
            self.item_stack[-1].appendRow(current_item)
        
        self.item_stack.append(current_item) # Empujar el item actual a la pila

    def exitEveryRule(self, ctx:ParserRuleContext):
        if self.item_stack:
            self.item_stack.pop() # Sacar el item de la pila al salir de la regla

    def visitTerminal(self, node:TerminalNode):
        if self.item_stack: # Solo añadir terminales si hay un item padre en la pila
            token = node.getSymbol()
            # No mostrar EOF o tokens de canal oculto en el árbol visual
            if token.type != Token.EOF and token.channel == Token.DEFAULT_CHANNEL:
                token_name = NaturalToJsonLexer.symbolicNames[token.type]
                terminal_text = f"{token_name}: '{node.getText()}'"
                terminal_item = QStandardItem(terminal_text)
                terminal_item.setEditable(False)
                # Podríamos colorear los terminales de forma diferente
                # terminal_item.setForeground(QColor("blue")) 
                self.item_stack[-1].appendRow(terminal_item)

# --- Funciones de Análisis (Modificada para devolver el QStandardItemModel) ---
def get_tokens_as_string(input_content_string):
    # ... (sin cambios) ...
    output_lines = ["--- Tokens Reconocidos por el Analizador Léxico ---"]
    lexer_instance = NaturalToJsonLexer(InputStream(input_content_string))    
    token_count = 0
    for token in lexer_instance.getAllTokens():
        if token.channel == Token.DEFAULT_CHANNEL:
            token_type_name = NaturalToJsonLexer.symbolicNames[token.type]
            output_lines.append(f"  ● Token #{token_count}: Tipo={token_type_name:<18} Texto='{token.text}' (L:{token.line}, C:{token.column+1})")
            token_count += 1
    if token_count == 0:
        output_lines.append("  No se reconocieron tokens del canal por defecto.")
    output_lines.append("-------------------------------------------------\n")
    return "\n".join(output_lines)


def analyze_and_transform(source_name, input_content):
    """
    Devuelve: (json_string, tokens_string, parsetree_model, error_summary_string, stats_dict)
    parsetree_model es un QStandardItemModel.
    """
    start_time = time.time()
    tokens_string_output = get_tokens_as_string(input_content)

    input_stream = InputStream(input_content)
    lexer = NaturalToJsonLexer(input_stream)
    error_listener = CustomErrorListener(source_name)
    
    lexer.removeErrorListeners()
    lexer.addErrorListener(error_listener)

    token_stream = CommonTokenStream(lexer)
    try:
        token_stream.fill() 
    except Exception as e:
        error_listener.error_messages.append(f"Error crítico durante la tokenización inicial: {e}")

    parser = NaturalToJsonParser(token_stream)
    parser.removeErrorListeners()
    parser.addErrorListener(error_listener)

    tree = parser.programa() # Árbol de parseo de ANTLR

    parsetree_qt_model = None # Modelo para QTreeView
    json_output_string = None
    num_comandos = 0
    
    if error_listener.get_total_errors() == 0 and tree:
        # Construir el modelo para QTreeView
        model_builder = ParseTreeModelBuilder(list(NaturalToJsonParser.ruleNames))
        walker = ParseTreeWalker()
        walker.walk(model_builder, tree)
        parsetree_qt_model = model_builder.get_model()
        
        # Construir JSON
        json_builder = JsonBuilderListener()
        walker.walk(json_builder, tree) # Reutilizar el walker
        json_output_string = json_builder.get_final_json_string()
        num_comandos = len(json_builder.result_data)
    
    error_summary_output = error_listener.get_error_summary_string()
    end_time = time.time()
    analysis_time = end_time - start_time
    parser_tokens_count = sum(1 for t in token_stream.tokens if t.channel == Token.DEFAULT_CHANNEL and t.type != Token.EOF)

    stats = {
        "tiempo_analisis_seg": round(analysis_time, 4),
        "comandos_procesados": num_comandos,
        "tokens_al_parser": parser_tokens_count,
        "errores_lexicos": error_listener.lexer_errors,
        "errores_sintacticos": error_listener.parser_errors
    }
    # Devolvemos el modelo Qt en lugar del string LISP del árbol
    return json_output_string, tokens_string_output, parsetree_qt_model, error_summary_output, stats